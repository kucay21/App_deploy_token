import { ethers } from "ethers";

// 🔹 paste ABI hasil compile di sini
const abi = [ /* ... */ ];

// 🔹 paste Bytecode hasil compile di sini
const bytecode = "0x6080604052...";

export default async function handler(req, res) {
  try {
    const { name, symbol, supply } = req.body || {
      name: "TestToken",
      symbol: "TTK",
      supply: 1000000
    };

    const provider = new ethers.JsonRpcProvider("https://sepolia.base.org");
    const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);

    const factory = new ethers.ContractFactory(abi, bytecode, wallet);
    const contract = await factory.deploy(name, symbol, supply);
    await contract.waitForDeployment();

    const tokenAddress = contract.target;

    res.json({
      version: "1",
      image: "https://yourapp.vercel.app/success-frame.png",
      buttons: [
        {
          label: "🔗 View Token",
          action: "link",
          target: `https://sepolia.basescan.org/address/${tokenAddress}`
        }
      ]
    });
  } catch (err) {
    res.json({
      version: "1",
      image: "https://yourapp.vercel.app/error-frame.png",
      buttons: [{ label: "retry" }]
    });
  }
}