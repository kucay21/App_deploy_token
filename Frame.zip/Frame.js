export default function handler(req, res) {
  res.json({
    version: "1",
    image: "https://yourapp.vercel.app/deploy-frame.png",
    buttons: [
      {
        label: "🚀 Deploy Token",
        action: "post",
        target: "https://yourapp.vercel.app/api/deploy"
      }
    ]
  });
}